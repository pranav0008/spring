package com.cg.mobilebilling;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.mobilebilling.daoservices.BillDAO;
import com.cg.mobilebilling.daoservices.CustomerDAO;
import com.cg.mobilebilling.daoservices.PlanDAO;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAO;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MobileBillingApplicationTests {

	private static BillDAO mockBillDao;
	private static PostpaidAccountDAO mockPostpaidDao;
	private static PlanDAO mockPlanDao;
	private static CustomerDAO mockcustomerDao;
	@Test
	public void contextLoads() {
	}
	
}
