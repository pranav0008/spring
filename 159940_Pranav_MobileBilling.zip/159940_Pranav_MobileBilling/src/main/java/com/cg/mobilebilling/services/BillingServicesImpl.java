package com.cg.mobilebilling.services;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillDAO;
import com.cg.mobilebilling.daoservices.CustomerDAO;
import com.cg.mobilebilling.daoservices.PlanDAO;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAO;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
@Component(value="billingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired	
	PlanDAO planDao;
	@Autowired
	CustomerDAO customerDao;
	@Autowired
	PostpaidAccountDAO ppaDao;
	@Autowired
	BillDAO billDao;
	static int flag=0;
	Bill bill;
	
	
	
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		return planDao.findAll();
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer)throws BillingServicesDownException {
		if (flag==0) {
			Plan plan1 = new Plan(1,500,10,10,50,50,1000,0.1f,0.2f,0.1f,0.2f,0.1f,"Delhi","Plan1");
			
			Plan plan2 = new Plan(2,400,10,10,50,50,900,0.1f,0.2f,0.1f,0.2f,0.1f,"Haryana","Plan2");
			
			Plan plan3= new Plan(3,200,5,5,30,30,500,0.1f,0.2f,0.1f,0.2f,0.1f,"Rajisthan","plan3");
			planDao.save(plan1);
			planDao.save(plan2);
			planDao.save(plan3);
			flag++;
		}
		return customerDao.save(customer);
	}

	@Override
	public PostpaidAccount openPostpaidMobileAccount(int customerID,int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Plan plan = planDao.findById(planID).orElseThrow(()->
		new PlanDetailsNotFoundException("plan details are not found"));
		Customer customer = customerDao.findById(customerID).orElseThrow(()-> 
		new CustomerDetailsNotFoundException("customer details not found"));;
		PostpaidAccount postpaidAccount = new PostpaidAccount(plan,customer);
		return ppaDao.save(postpaidAccount);
	}

	@Override
	public int generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		PostpaidAccount postpaidAccount = ppaDao.findById(mobileNo).get();
		if(postpaidAccount==null)
			throw new PostpaidAccountNotFoundException();
		Plan plan=postpaidAccount.getPlan();
		if(plan==null)
			throw new PlanDetailsNotFoundException();
		
		if(noOfLocalSMS>plan.getFreeLocalSMS())
			noOfLocalSMS-=plan.getFreeLocalSMS();
		else
			noOfLocalSMS=0;
		
		if(noOfLocalCalls>plan.getFreeLocalCalls())
			noOfLocalCalls-=plan.getFreeLocalCalls();
		else
			noOfLocalCalls=0;
		
		if(noOfStdSMS>plan.getFreeStdSMS())
			noOfStdSMS-=plan.getFreeStdSMS();
		else
			noOfStdSMS=0;
		
		if(noOfStdCalls>plan.getFreeStdCalls())
			noOfStdCalls-=plan.getFreeStdCalls();
		else
			noOfStdCalls=0;
		
		if(internetDataUsageUnits>plan.getFreeInternetDataUsageUnits())
			internetDataUsageUnits-=plan.getFreeInternetDataUsageUnits();
		
		int localSMSAmount = (int) (noOfLocalSMS*plan.getLocalSMSRate());
		int stdSMSAmount = (int) (noOfStdSMS*plan.getStdSMSRate());
		int localCallAmount = (int) (noOfLocalCalls*plan.getLocalCallRate());
		int stdCallAmount = (int) (noOfStdCalls*plan.getStdCallRate());
		int internetDataUsageAmount = (int) (internetDataUsageUnits*plan.getInternetDataUsageRate());
		int monthlyRental=plan.getMonthlyRental();
		int billAmount=monthlyRental+localSMSAmount+stdSMSAmount+localCallAmount+stdCallAmount+internetDataUsageAmount;
		int servicesTax = (int)billAmount*10/100;
		int vat = (int)billAmount*5/100;
		int totalBillAmount = billAmount+servicesTax+vat;
		
		Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, servicesTax, vat, postpaidAccount);
		bill=billDao.save(bill);
		return totalBillAmount;
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		
		return customerDao.findById(customerID).orElseThrow(()-> 
		new CustomerDetailsNotFoundException("customer details not found"));
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		return customerDao.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		customerDao.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("customer details not found"));
		ppaDao.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("postpaid account not found"));
		
		return ppaDao.getCustomerPostPaidAccount(customerID, mobileNo);
		
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		
		
		customerDao.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("customer details not found"));
		List<PostpaidAccount> postpaidAccounts= ppaDao.getCustomerAllpostpaidAccounts(customerID);
		return postpaidAccounts;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, DocumentException, FileNotFoundException
			 {	customerDao.findById(customerID).orElseThrow(()->
				new CustomerDetailsNotFoundException("customer details not found"));
			 ppaDao.findById(mobileNo).orElseThrow(()->
				new PostpaidAccountNotFoundException("postpaid account not found"));
			 Bill bill= billDao.getMonthlyBill(customerID, mobileNo, billMonth);
			 System.out.println(bill.toString());
			 Document document = new Document();
				String string="D:\\pranav\\Bill "+billMonth+".pdf";
				PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(string));
				document.open();
				document.add(new Paragraph("Customer Id: "+customerID));
				document.add(new Paragraph("mobileNo : "+mobileNo));
				document.add(new Paragraph("Bill Month: "+billMonth));
				document.add(new Paragraph("localSMSAmount: "+bill.getLocalSMSAmount()));
				document.add(new Paragraph("StdSMSAmount: "+bill.getStdSMSAmount()));
				document.add(new Paragraph("LocalCallAmount: "+bill.getLocalCallAmount()));
				document.add(new Paragraph("StdCallAmount: "+bill.getStdCallAmount()));
				document.add(new Paragraph("InternetDataUsageAmount: "+bill.getInternetDataUsageAmount()));	
				document.add(new Paragraph("ServiceTax: "+bill.getServicesTax()));	
				document.add(new Paragraph("VAT:" + bill.getVat()));	
				document.add(new Paragraph("TotalBillAmount: "+customerID));	
				document.close();
				writer.close();
			 return bill;
			}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		customerDao.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("customer details not found"));
	 ppaDao.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("postpaid account not found"));
	 System.out.println(billDao.getCustomerPostPaidAccountAllBills(customerID, mobileNo).toString());
		return billDao.getCustomerPostPaidAccountAllBills(customerID, mobileNo);
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		customerDao.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("customer details not found"));
		ppaDao.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("postpaid account not found"));
		planDao.findById(planID).orElseThrow(()->
		new PlanDetailsNotFoundException("plan is not found"));
		ppaDao.changePlan(customerID, mobileNo, planID);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		ppaDao.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("postpaid account not found"));
		ppaDao.deletepostpaidAccountById(mobileNo);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		if(customerDao.findById(customerID).isPresent()==false)
		throw new CustomerDetailsNotFoundException();
		customerDao.deleteCustomerById(customerID);
		return true;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		customerDao.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("customer details not found"));
		ppaDao.findById(mobileNo).orElseThrow(()-> 
		new PostpaidAccountNotFoundException("postpaid account not found"));
		PostpaidAccount postpaidAccount=ppaDao.getCustomerPostPaidAccount(customerID, mobileNo);
		return postpaidAccount.getPlan();
	}
}