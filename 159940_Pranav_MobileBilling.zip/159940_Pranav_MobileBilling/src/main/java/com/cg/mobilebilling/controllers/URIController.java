package com.cg.mobilebilling.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;

@Controller
public class URIController {

	Customer customer;
	Plan plan;
	Bill bill;
	PostpaidAccount postpaidAccount;
	
	@RequestMapping(value= {"/","home"})
	public String getIndexPage(){
		return "indexPage";
	}
	@RequestMapping("/register")
	public String getdisplayNewCustomerDetailsPage(){
		return "registerPage";
		
	}@RequestMapping("/customerDetails")
	public String getcustomerDetailsPage(){
		return "getCustomerDetailsPage";
	}
	/*@RequestMapping("/allCustomerDetailsPage")
	public String getAllCustomerDetailsPage(){
		return "AllCustomerDetailsPage";
	}*/
	@RequestMapping("/customerAllPostpaidAccountsDetails")
	public String getCustomerAllPostpaidAccountsDetailsPage(){
		return "getCustomerAllPostpaidAccountsDetailsPage";
	}
	
	@RequestMapping("/customerPostPaidAccountAllBillDetails")
	public String getCustomerPostPaidAccountAllBillDetailsPage(){
		return "getCustomerPostPaidAccountAllBillDetails";
		
	}@RequestMapping("/deleteCustomer")
	public String getdeleteCustomerPage(){
		
		return "getDeleteCustomerPage";
		
	}@RequestMapping("/closeCustomerPostPaidAccount")
	public String getcloseCustomerPostPaidAccountPage(){
		return "getDeletePostpaidAccountPage";
		
	}@RequestMapping("/customerPostPaidAccountPlanDetails")
	public String getCustomerPostPaidAccountPlanDetailsPage(){
		return "getCustomerPostPaidAccountPlanDetailsPage";
	}
	/*@RequestMapping("/planAllDetailsPage")
	public String getPlanAllDetailsPage(){
		return "PlanAllDetailsPage";
	}*/
	@RequestMapping("/postPaidAccountDetails")
	public String getPostPaidAccountDetailsPage(){
		return "getPostpaidAccountDetailsPage";
	}
	@RequestMapping("/mobileBillDetails")
	public String getMobileBillDetailsPage(){
		return "getMobileBillDetailsPage";
	}
	@RequestMapping("/openPostpaidMobileAccount")
	public String getdisplayPostpaidAccountDetailsPage(){
		return "getOpenPostpaidMobileAccountPage";
	}
	@RequestMapping("/changePlan")
	public String changePlan(){
		return "getChangePlanPage";
	}
	@RequestMapping("/generateMonthlyMobileBill")
	public String generateMonthlyBill(){
		return "getGenerateMonthlyMobileBillPage";
	}
	@RequestMapping("/generatePDF")
	public String generatePDF(){
		return "getCustomerPostPaidAccountAllBillDetails";
	}
	
	
	@ModelAttribute
	public Customer getCustomer() {
		customer = new Customer();
		return customer;
	}
	@ModelAttribute
	public Bill getBill() {
		bill = new Bill();
		return bill;
	}
	@ModelAttribute
	public Plan getPlan() {
		plan = new Plan();
		return plan;
	}
	@ModelAttribute
	public PostpaidAccount getPostpaidAccount() {
		postpaidAccount = new PostpaidAccount();
		return postpaidAccount;
	}
}
