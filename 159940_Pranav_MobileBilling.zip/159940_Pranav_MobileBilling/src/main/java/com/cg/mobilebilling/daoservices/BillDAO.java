package com.cg.mobilebilling.daoservices;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.mobilebilling.beans.Bill;
@Qualifier("JpaRepository")
public interface BillDAO extends JpaRepository<Bill , Integer>{
	@Query(value="SELECT a FROM Bill a WHERE a.billMonth=:billMonth AND a.postpaidAccount.mobileNo IN "
			+ "(SELECT b.mobileNo FROM PostpaidAccount b WHERE b.customer.customerID=:customerID AND "
			+ "b.mobileNo=:mobileNo)")
	Bill getMonthlyBill(@Param("customerID")int customerID,@Param("mobileNo") long mobileNo,@Param("billMonth") String billMonth);
	
	@Query(value="SELECT a FROM Bill a WHERE a.postpaidAccount.mobileNo IN "
			+ "(SELECT b.mobileNo FROM PostpaidAccount b"
			+ " WHERE b.customer.customerID=:customerID AND b.mobileNo=:mobileNo)")
	List<Bill> getCustomerPostPaidAccountAllBills(@Param("customerID") int customerID,@Param("mobileNo") long mobileNo);
}
