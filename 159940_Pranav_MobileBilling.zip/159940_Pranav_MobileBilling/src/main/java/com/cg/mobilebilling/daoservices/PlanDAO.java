package com.cg.mobilebilling.daoservices;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.mobilebilling.beans.Plan;
@Qualifier("JpaRepository")
public interface PlanDAO extends JpaRepository<Plan,Integer>{
	@Query(value="SELECT a FROM plan a WHERE a.planID IN "
	+ "(SELECT b.planID FROM postpaidAccount b WHERE "
	+ "b.customerID=:customerID AND b.mobileNo=:mobileNo)",nativeQuery=true)
	Plan getPlanDetails(@Param("customerID")int customerID,@Param("mobileNo") long mobileNo);
}

