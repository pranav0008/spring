package com.cg.mobilebilling.controllers;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.services.GeneratePDF;
import com.itextpdf.text.DocumentException;

@Controller
public class MobileBillingController {
	
@Autowired
private BillingServices billingServices;
	//1 done
	@RequestMapping("/registerCustomer")
	public ModelAndView registerAssociateAction(@Valid @ModelAttribute Customer customer,BindingResult result) throws BillingServicesDownException {
		if(result.hasErrors())
			return new ModelAndView("CustomerDetailsPage");
		customer = billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("accountOpeningSuccessPage","customer",customer);
	}
	//3 done
	@RequestMapping("/displayCustomer")
	public ModelAndView registerAssoeAction(@RequestBody @RequestParam("customerID") int customerID) throws CustomerDetailsNotFoundException, BillingServicesDownException {
		return new ModelAndView("displayCustomerDetailsPage","customer",billingServices.getCustomerDetails(customerID));
	}//4 done
	@RequestMapping("/allCustomerDetails")
	public ModelAndView registerAssociateAction() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		return new ModelAndView("displayAllCustomerDetailsPage","customers",billingServices.getAllCustomerDetails());
	}
	@RequestMapping("/displayCustomerAllPostpaidAccountsDetails")
	public ModelAndView registerAssociateAction(@RequestParam("customerID") int customerID) throws CustomerDetailsNotFoundException, BillingServicesDownException {
		return new ModelAndView("displayCustomerAllPostpaidAccountsDetailsPage","postpaidAccounts",billingServices.getCustomerAllPostpaidAccountsDetails(customerID));
	}
	@RequestMapping("/displayCustomerPostPaidAccountAllBillDetails")
	public ModelAndView registerAssociate(@RequestParam("customerID") int customerID,@RequestParam("mobileNo") long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, BillDetailsNotFoundException {
		return new ModelAndView("displayCustomerPostPaidAccountAllBillDetailsPage","bills",billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo));
	}
	
	@RequestMapping("/DeleteCustomer")
	public ModelAndView registerAssociate(@RequestParam("customerID") int customerID) throws BillingServicesDownException, CustomerDetailsNotFoundException {
		billingServices.deleteCustomer(customerID);
		return new ModelAndView("getDeleteCustomerPage","successMessage","customer has been deleted");
	}
	//6done
	@RequestMapping("/deletePostpaidAccount")
	public ModelAndView registerAssociateAction(@RequestParam("customerID")int customerID,@RequestParam("mobileNo") long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		billingServices.closeCustomerPostPaidAccount(customerID, mobileNo);
		return new ModelAndView("getDeletePostpaidAccountPage","successMessage","your postpaid account has been deleted");
	}
	@RequestMapping("/CustomerPostPaidAccountPlanDetailsPage")
	public ModelAndView registerAction(@RequestParam("customerID")int customerID, @RequestParam("mobileNo") long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
	return new ModelAndView("displayCustomerPostPaidAccountPlanDetailsPage","plan",billingServices.getCustomerPostPaidAccountPlanDetails(customerID, mobileNo));
	}
	@RequestMapping("/allPlanDetails")
	public ModelAndView registerAction() throws BillingServicesDownException {
		return new ModelAndView("displayAllPlanDetailsPage","plans",billingServices.getPlanAllDetails());
	}//5 done
	@RequestMapping("/displayPostPaidAccountDetails")
	public ModelAndView registerBillAction(@RequestParam("customerID")int customerID, @RequestParam("mobileNo") long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		return new ModelAndView("displayCustomerPostPaidAccountPage","postpaidAccount",billingServices.getPostPaidAccountDetails(customerID, mobileNo));
	}
	
	@RequestMapping("/displayMonthlyBillDetailsAll")
	public ModelAndView registerBillAction(@RequestParam("customerID")int customerID, @RequestParam("mobileNo")long mobileNo,@RequestParam("billMonth") String billMonth) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, BillingServicesDownException, DocumentException, FileNotFoundException {
	return new ModelAndView("displayMonthlyMobileBilldetails","bill",billingServices.getMobileBillDetails(customerID, mobileNo, billMonth));	
	}
	//2 done
	@RequestMapping("/openPostpaidAccount")
	public ModelAndView registerAssociateAction(@RequestParam("customerID") int customerID, @RequestParam("planID") int planID) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		return new ModelAndView("displayPostPaidAccountDetailsPage","postpaidAccount", billingServices.openPostpaidMobileAccount(customerID,planID));
	}
	
	@RequestMapping("/ChangePlan")
	public ModelAndView registerPlanAction(@RequestParam("customerID") int customerID,@RequestParam("mobileNo")long mobileNo, @RequestParam("planID") int planID) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		billingServices.changePlan(customerID, mobileNo, planID);
		return new ModelAndView("getChangePlanPage","successMessage","plans have been changed");
	}
	@RequestMapping("/GenerateMonthlyMobileBill")
	public ModelAndView registermonthlyBillAction(@RequestParam("customerID") int customerID,@RequestParam("mobileNo")long mobileNo,
	@RequestParam("billMonth") String billMonth,@RequestParam("noOfLocalSMS") int noOfLocalSMS,@RequestParam("noOfStdSMS") int noOfStdSMS ,
	@RequestParam("noOfLocalCalls") int noOfLocalCalls, @RequestParam("noOfStdCalls") int noOfStdCalls, @RequestParam("internetDataUsageUnits") int internetDataUsageUnits ) throws BillingServicesDownException,InvalidBillMonthException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
    return new ModelAndView("displayMonthlyMobileBillPage","totalBillAmount",billingServices.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits));
	}
	@RequestMapping(value = "/allBillsPdfReport", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_PDF_VALUE )
    public ResponseEntity<InputStreamResource> getAllBillsPdfReport(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo) throws IOException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, BillDetailsNotFoundException, PlanDetailsNotFoundException, DocumentException {

        List<Bill> bills =  billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);

        ByteArrayInputStream bis = GeneratePDF.billsReport(bills);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=billsreport.pdf");

        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(bis));
    }
	
//	public ModelAndView registerAssociateAction(@Valid @ModelAttribute Account account,BindingResult result)  {
//		if(result.hasErrors())
//			return new ModelAndView("openAccountPage");
//			account=bankingServices.openAccount(account);
//		return new ModelAndView("displayNewAccountDetails","account",account);}
}
