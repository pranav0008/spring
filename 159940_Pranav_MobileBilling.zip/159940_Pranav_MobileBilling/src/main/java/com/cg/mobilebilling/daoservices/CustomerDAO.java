package com.cg.mobilebilling.daoservices;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.mobilebilling.beans.Customer;

@Qualifier("JpaRepository")
public interface CustomerDAO extends JpaRepository<Customer, Integer>{
	@Transactional
	@Modifying
	@Query("DELETE FROM Customer a WHERE a.customerID=:customerID")
	int deleteCustomerById(@Param("customerID")int customerID);
}
