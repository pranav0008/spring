package com.cg.banking.services;
import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.InvalidInitBalance;
import com.cg.banking.exceptions.InvalidPinNumberException;
public interface BankingServices {
	Account  openAccount(Account account);
	float depositAmount(long accountNo,float amount);
	float withdrawAmount(long accountNo,float amount,int pinNumber) throws InvalidPinNumberException, InvalidInitBalance ;
	boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber) throws com.cg.banking.exceptions.InvalidInitBalance, com.cg.banking.exceptions.InvalidPinNumberException;
	Account getAccountDetails(long accountNo);
	ArrayList<Account> getAllAccountDetails();
	ArrayList<Transaction> getAllTransactionDetails(long accountNo);
}