package com.cg.banking.beans;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
public class Account {
	private int pinNumber;
	private String accountType;
	private String status;
	private float accountBalance;
	@NotEmpty
	private String fullName;
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private long accountNo;
	@OneToMany(fetch=FetchType.EAGER,mappedBy="account")
	private List<Transaction> transaction;
	public Account() {
		super();
	}
	public Account(int pinNumber, String accountType, String status,
			float accountBalance, long accountNo, List<Transaction> transaction) {
		super();
		this.pinNumber = pinNumber;
		this.accountType = accountType;
		this.status = status;
		this.accountBalance = accountBalance;
		this.accountNo = accountNo;
		this.transaction = transaction;
	}
	public Account(int pinNumber, String accountType, String status,
			float accountBalance) {
		super();
		this.pinNumber = pinNumber;
		this.accountType = accountType;
		this.status = status;
		this.accountBalance = accountBalance;
	}
	public Account(long accountNo) {
		super();
		this.accountNo = accountNo;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public List<Transaction> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<Transaction> transaction) {
		this.transaction = transaction;
	}
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	@Override
	public String toString() {
		return "Account [pinNumber=" + pinNumber + ", accountType=" + accountType + ", status=" + status
				+ ", accountBalance=" + accountBalance + ", fullName=" + fullName + ", accountNo=" + accountNo
				+ ", transaction=" + transaction + "]";
	}

}