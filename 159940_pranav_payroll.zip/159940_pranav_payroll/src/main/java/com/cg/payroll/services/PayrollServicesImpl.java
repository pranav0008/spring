package com.cg.payroll.services;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/*import org.apache.log4j.Logger;
*/
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;


@Component(value="payrollServices")
public class PayrollServicesImpl implements PayrollServices {
	@Autowired
	private AssociateDAO associateDAO;
	//private static final Logger logger = Logger.getLogger(PayrollServicesImpl.class);
	@Override
	public Associate acceptAssociateDetails(Associate associate) {
			associate=associateDAO.save(associate);
			return associate;
		
	}

	@Override
	public int calculateNetSalary(int associateId) {
		Associate associate = getAssociateDetails(associateId);
		Salary NetSalaryAfterTaxes = new Salary();
		NetSalaryAfterTaxes = associate.getSalary();
		int tax = 0;
		if(associate.getYearlyInvestmentUnder80C() > 150000)
			associate.setYearlyInvestmentUnder80C(150000);
		if(associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C() < 250000){
			NetSalaryAfterTaxes.setNetSalary(associate.getSalary().getGrossSalary());
		}
		else if(associate.getSalary().getGrossSalary()- associate.getYearlyInvestmentUnder80C() > 250000 && associate.getSalary().getGrossSalary()- associate.getYearlyInvestmentUnder80C() < 500000){
			tax = (int)(0.05*associate.getSalary().getGrossSalary() - associate.getYearlyInvestmentUnder80C());
			NetSalaryAfterTaxes.setNetSalary(associate.getSalary().getGrossSalary() - tax);
			}
		else if(associate.getSalary().getGrossSalary()- associate.getYearlyInvestmentUnder80C() > 500000 &&  associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()<1000000){
			tax=(int) (0.20*(associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()-500000)+(12500));
			NetSalaryAfterTaxes.setNetSalary(associate.getSalary().getGrossSalary()-tax);
		}
		else{
			tax=(int) (0.30*(associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()-1000000)+(112500));
			NetSalaryAfterTaxes.setNetSalary(associate.getSalary().getGrossSalary()-tax);
		}NetSalaryAfterTaxes.setMonthlyTax(tax);
		associate.setSalary(NetSalaryAfterTaxes);
		
		return NetSalaryAfterTaxes.getBasicSalary();
	}

	@Override
	public Associate getAssociateDetails(int associateId) {
		Associate associate = associateDAO.findById(associateId).get();
		return associate;
	}

	@Override
	public ArrayList<Associate> getAllAssociatesDetails(){
		return (ArrayList<Associate>) associateDAO.findAll();
	}



}
