package com.cg.payroll.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.config.annotation.AsyncSupportConfigurer;

import com.cg.payroll.beans.Associate;

@Controller
public class URIController {
	Associate associate;
	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping(value="/registration",method = RequestMethod.GET)
public String getRegistrationPage() {
	return "SignUpPage";
}	
	@ModelAttribute
	public Associate getAssociate() {
		associate=new Associate();
		return associate;
	}
}
