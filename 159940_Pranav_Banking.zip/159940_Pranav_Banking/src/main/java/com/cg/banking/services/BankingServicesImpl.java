package com.cg.banking.services;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.InvalidInitBalance;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Component("bankingServices")
public class BankingServicesImpl implements BankingServices {
	@Autowired
	private AccountDAO accountdao;
	@Autowired
	private TransactionDAO transactionDAO;
	@Override
	public Account openAccount(Account account)
	{
		account=	accountdao.save(account);
		return account;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
	{
		Account account = getAccountDetails(accountNo);
		account.setAccountBalance(account.getAccountBalance()+amount);
		Transaction transaction=new Transaction(amount, "deposit", account); 
		transactionDAO.save(transaction);
		accountdao.save(account);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InvalidPinNumberException, InvalidInitBalance  {
		Account account = getAccountDetails(accountNo);
		if(account.getPinNumber()==pinNumber){
			if(account.getAccountBalance()-amount>1000||amount<=0){
				account.setAccountBalance(account.getAccountBalance()-amount);
				Transaction transaction=new Transaction(amount, "withdraw", account); 
				transactionDAO.save(transaction);
				accountdao.save(account);
			}
			else
				throw new InvalidInitBalance("Invalid Amount or Insufficient Balance");
			return account.getAccountBalance();
		}
		else throw new InvalidPinNumberException("Incorrect pin number");
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber) throws InvalidInitBalance, InvalidPinNumberException
	{
		Account account1;
		account1 = getAccountDetails(accountNoTo);
		Account account2=getAccountDetails(accountNoFrom);
		if(account2.getPinNumber()==pinNumber){
			if(account2.getAccountBalance()-transferAmount>1000){
				account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
				account2.setAccountBalance(account2.getAccountBalance()-transferAmount);
				Transaction transaction1=new Transaction(transferAmount, "deposit", account1); 
				Transaction transaction2=new Transaction(transferAmount, "withdraw", account2); 
				transactionDAO.save(transaction1); 
				transactionDAO.save(transaction2);
				accountdao.save(account1);
				accountdao.save(account2);
			}
			else
				throw new InvalidInitBalance("Invalid Amount or Insufficient Balance");
			return false;
		}
		else throw new InvalidPinNumberException("Incorrect pin number");
	}

	@Override
	public Account getAccountDetails(long accountNo)  {
		Account account=accountdao.findById(accountNo).get();
		return account;		
	}

	@Override
	public ArrayList<Account> getAllAccountDetails() {

		return (ArrayList<Account>) accountdao.findAll();
	}

	@Override
	public ArrayList<Transaction> getAllTransactionDetails(long accountNo)
	{	

		Account account=accountdao.findById(accountNo).get();
		return (ArrayList<Transaction>) transactionDAO.findAll();
	}




}
