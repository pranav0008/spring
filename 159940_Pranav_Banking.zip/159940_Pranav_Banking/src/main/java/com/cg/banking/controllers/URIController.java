package com.cg.banking.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.beans.Account;


@Controller
public class URIController {
	Account account;
	
@RequestMapping("/")
public String getIndexPage(){
	return "index";
}
@RequestMapping("/index")
public String backToIndexPage(){
	return "index";
}
@RequestMapping("/openAccountPage")
public String getopenAccountPage() {
	return "openAccountPage";
}
@ModelAttribute
public Account getAccount() {
	account=new Account();
	return account;
}
@RequestMapping("/depositAmountPage")
public String getdepositAmountPage() {
	return "depositAmountPage";
}
@RequestMapping("/withdrawAmountPage")
public String getWithdrawAmountPage() {
	return "withdrawAmountPage";
}
@RequestMapping("/fundsTransferPage")
public String getfundsTransferPage() {
	return "fundsTransferPage";
}
@RequestMapping("/getAccountDetailsPage")
public String getAccountDetailsPage() {
	return "getAccountDetailsPage";
}
@RequestMapping("/getAccountAllTransactionDetailsPage")
public String GetAccountAllTransactionDetails() {
	return "getAccountAllTransactionDetailsPage";
}
@RequestMapping("/Transactions")
public String Transactions() {
	return "Transactions";
}
}
