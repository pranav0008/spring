package com.cg.banking.controllers;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.services.BankingServices;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.InvalidInitBalance;
import com.cg.banking.exceptions.InvalidPinNumberException;


@Controller
public class AccountController {

	@Autowired
private BankingServices bankingServices;

@RequestMapping("/registerAccount")
public ModelAndView registerAssociateAction(@Valid @ModelAttribute Account account,BindingResult result)  {
if(result.hasErrors())
	return new ModelAndView("openAccountPage");
	account=bankingServices.openAccount(account);
return new ModelAndView("displayNewAccountDetails","account",account);}

@RequestMapping("/DepositAmount")
public ModelAndView registerAssociateAction(@RequestParam("accountNo")int accountNo, @RequestParam("amount")float amount)  {
	float accountBalance=bankingServices.depositAmount(accountNo, amount);
	return new ModelAndView("depositDisplaySuccessful","accountBalance",accountBalance);}

@RequestMapping("/WithdrawAmount")
public ModelAndView registerAssociateAction(@RequestParam("accountNo")int accountNo, @RequestParam("amount")float amount,@RequestParam("pinNumber")int pinNumber) throws InvalidPinNumberException, InvalidInitBalance  {
	float accountBalance=bankingServices.withdrawAmount(accountNo, amount, pinNumber);
	return new ModelAndView("withdrawDisplaySuccessful","accountBalance",accountBalance);}

@RequestMapping("/FundsTransfer")
public ModelAndView registerAssociateAction(@RequestParam("accountNoFrom")int accountNoFrom,@RequestParam("accountNoTo")int accountNoTo, @RequestParam("amount")float amount,@RequestParam("pinNumber")int pinNumber) throws InvalidPinNumberException, InvalidInitBalance  {
	bankingServices.fundTransfer(accountNoTo, accountNoFrom, amount, pinNumber);
	return new ModelAndView("fundsTransferDisplaySuccessful");}

@RequestMapping("/GetAccountDetails")
public ModelAndView registerAssociateAction(@RequestParam("accountNo")int accountNo)  {
	Account account=bankingServices.getAccountDetails(accountNo);
	return new ModelAndView("displayAccountDetails","account",account);}

@RequestMapping("/GetAccountAllTransactionDetails")
public ModelAndView registerAccountAction(@RequestParam("accountNo")int accountNo)  {
	ArrayList<Transaction> transactions=bankingServices.getAllTransactionDetails(accountNo);
	return new ModelAndView("displayAccountAllTransactionDetails","transactions",transactions);}

}
