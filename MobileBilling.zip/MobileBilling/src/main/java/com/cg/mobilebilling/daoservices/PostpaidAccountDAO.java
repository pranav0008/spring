package com.cg.mobilebilling.daoservices;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.mobilebilling.beans.PostpaidAccount;
@Qualifier("JpaRepository")
public interface PostpaidAccountDAO extends JpaRepository<PostpaidAccount,Long>{
	@Query("SELECT a FROM PostpaidAccount a"
			+ " WHERE a.customer.customerID=:customerID AND"
			+ " a.mobileNo=:mobileNo")
	PostpaidAccount getCustomerPostPaidAccount(@Param("customerID")int customerID,@Param("mobileNo") long mobileNo);
	
	@Query("SELECT a FROM PostpaidAccount a"
			+ " WHERE a.customer.customerID=:customerID ")
	List<PostpaidAccount> getCustomerAllpostpaidAccounts(@Param("customerID")int customerID);
	
	@Transactional
	@Modifying
	@Query("UPDATE PostpaidAccount a SET a.plan.planID=:planID WHERE a.mobileNo=:mobileNo "
			+ "AND a.customer.customerID=:customerID")
	int changePlan(@Param("customerID")int customerID,@Param("mobileNo") long mobileNo,@Param("planID") int planID);
	
	@Transactional
	@Modifying
	@Query("DELETE FROM PostpaidAccount a WHERE a.mobileNo=:mobileNo")
	int deletepostpaidAccountById(@Param("mobileNo")long mobileNo);
}
